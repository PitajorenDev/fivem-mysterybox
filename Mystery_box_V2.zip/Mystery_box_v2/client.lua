-- client.lua
local function debugPrint(...)
    print('[MysteryBox CLIENT]', ...)
end

-- Compat: luister naar meerdere mogelijke ox_inventory use events
-- 1) moderne ox_inventory event
AddEventHandler('ox_inventory:usedItem', function(item)
   -- if not item then return end
   -- debugPrint('ox_inventory:usedItem fired for', item.name)
    if item.name == 'mystery_box' then
        TriggerServerEvent('mystery_box:openBox')
    end
end)

-- 2) alternatief event name sommige versies gebruiken
RegisterNetEvent('ox_inventory:useItem', function(item)
    debugPrint('ox_inventory:useItem fired', item and item.name or 'nil')
    if item and item.name == 'mystery_box' then
        TriggerServerEvent('mystery_box:openBox')
    end
end)

-- 3) direct client event in item definition (if someone used client.event = 'mystery_box:use')
RegisterNetEvent('mystery_box:use', function(item)
    debugPrint('mystery_box:use fired')
    TriggerServerEvent('mystery_box:openBox')
end)

-- StartSpin ontvangen van server
RegisterNetEvent('mystery_box:startSpin', function(reward)
  --  debugPrint('startSpin received, reward =', reward and (reward.label or reward.name) or 'nil')
    local ped = PlayerPedId()

    -- Anim + prop
    RequestAnimDict('mp_common')
    while not HasAnimDictLoaded('mp_common') do Wait(10) end

    local modelHash = GetHashKey('prop_cs_box_clothes')
    RequestModel(modelHash)
    local t0 = GetGameTimer()
    while not HasModelLoaded(modelHash) and (GetGameTimer() - t0) < 3000 do Wait(10) end

    local x, y, z = table.unpack(GetEntityCoords(ped))
    local boxProp = CreateObject(modelHash, x, y, z + 0.2, true, true, true)
    AttachEntityToEntity(boxProp, ped, GetPedBoneIndex(ped, 28422), 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, true, true, false, true, 1, true)

    TaskPlayAnim(ped, 'mp_common', 'givetake1_a', 8.0, -8.0, 3000, 49, 0, false, false, false)

    -- Gebruik exports ox_lib voor progressbar (zorg dat ox_lib draait)
    if exports.ox_lib and exports.ox_lib.progressBar then
        exports.ox_lib:progressBar({
            duration = 3000,
            label = 'Je opent de Mystery Box...',
            useWhileDead = false,
            canCancel = false,
            disable = { move = true, car = true, combat = true },
        })
    else
        -- fallback wait
        debugPrint('ox_lib not available, fallback wait')
        Wait(3000)
    end

    DeleteObject(boxProp)

    -- NUI openen met reward data
    debugPrint('Sending NUI message to open spin UI')
    SetNuiFocus(true, true)
    SendNUIMessage({
        action = 'open',
        rewards = Config.Rewards,
        finalReward = reward
    })
end)

-- finishSpin callback from NUI
RegisterNUICallback('finishSpin', function(data, cb)
    debugPrint('NUI finished spin, requesting server to give reward')
    SetNuiFocus(false, false)
    -- play rarity sound if present
    local rarity = data.reward and data.reward.rarity
    if rarity and Config.Rarities and Config.Rarities[rarity] then
        local r = Config.Rarities[rarity]
        PlaySoundFrontend(-1, r.sound or 'SELECT', r.soundset or 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    end
    -- vraag server om daadwerkelijk te geven (server-side veilige actie)
    TriggerServerEvent('mystery_box:giveReward', data.reward)
    cb({})
end)

-- Sparkle effect event (iedereen ziet het)
RegisterNetEvent('mystery_box:showSparkle', function(coords)
    RequestNamedPtfxAsset('scr_rcbarry2')
    while not HasNamedPtfxAssetLoaded('scr_rcbarry2') do Wait(10) end
    UseParticleFxAssetNextCall('scr_rcbarry2')
    local fx = StartParticleFxLoopedAtCoord('scr_clown_appears', coords.x, coords.y, coords.z + 0.8, 0.0, 0.0, 0.0, 1.2, false, false, false, false)
    Wait(2500)
    StopParticleFxLooped(fx, 0)
end)
