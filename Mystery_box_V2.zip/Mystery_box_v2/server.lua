local function GetWeightedReward()
    local totalChance = 0
    for _, reward in ipairs(Config.Rewards) do
        totalChance = totalChance + reward.chance
    end
    local randomNum = math.random() * totalChance
    local cumulative = 0
    for _, reward in ipairs(Config.Rewards) do
        cumulative = cumulative + reward.chance
        if randomNum <= cumulative then
            return reward
        end
    end
end

RegisterNetEvent('mystery_box:openBox', function()
    local src = source
    local hasBox = exports.ox_inventory:Search(src, 'count', 'mystery_box')
    if hasBox < 1 then
        TriggerClientEvent('ox_lib:notify', src, { type = 'error', description = 'Je hebt geen Mystery Box!' })
        return
    end

    exports.ox_inventory:RemoveItem(src, 'mystery_box', 1)
    local reward = GetWeightedReward()
    if not reward then return end

    TriggerClientEvent('mystery_box:startSpin', src, reward)
end)

RegisterNetEvent('mystery_box:giveReward', function(reward)
    local src = source
    if reward.type == 'item' then
        exports.ox_inventory:AddItem(src, reward.name, reward.count)
    elseif reward.type == 'weapon' then
        exports.ox_inventory:AddItem(src, reward.name, 1)
    elseif reward.type == 'money' or reward.type == 'black_money' then
        exports.ox_inventory:AddItem(src, reward.type, reward.amount)
    end

    local ped = GetPlayerPed(src)
    local coords = GetEntityCoords(ped)
    for _, id in ipairs(GetPlayers()) do
        if #(coords - GetEntityCoords(GetPlayerPed(id))) < 30.0 then
            TriggerClientEvent('mystery_box:showSparkle', id, coords)
        end
    end

    if reward.rarity == 'legendary' then
        TriggerClientEvent('ox_lib:notify', -1, {
            title = '🎉 Legendarische Drop!',
            description = GetPlayerName(src) .. ' kreeg een ' .. reward.label .. '!',
            type = 'success'
        })
    end
end)
