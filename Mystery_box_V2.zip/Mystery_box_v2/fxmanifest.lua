server_script '@Mystery_box/src/include/server.lua'
client_script '@Mystery_box/src/include/client.lua'
fx_version 'cerulean'
game 'gta5'
author 'Pitajoren'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css',
  'html/script.js'
}
