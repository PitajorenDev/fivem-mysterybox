let isSpinning = false;

window.addEventListener('message', (event) => {
  const data = event.data;
  if (!data || data.action !== 'open') return;
  startSpin(data.rewards, data.finalReward);
});

function startSpin(rewards, finalReward) {
  if (isSpinning) return;
  isSpinning = true;
  document.body.style.display = 'flex';

  const container = document.getElementById('container');
  const wheel = document.getElementById('wheel');
  wheel.innerHTML = '';

  // lange lijst met willekeurige items
  const seq = [];
  for (let i = 0; i < 150; i++) {
    seq.push(rewards[Math.floor(Math.random() * rewards.length)]);
  }
  const finalPos = seq.length - Math.floor(Math.random() * 8 + 4);
  seq[finalPos] = finalReward;

  // alle icons
  seq.forEach((r) => {
    const el = document.createElement('div');
    el.className = 'item';
// Fix voor money / cash
let imgSrc;
if (r.type === 'money' || r.name === 'money' || r.name === 'cash') {
  imgSrc = `nui://${GetParentResourceName()}/html/images/money.png`; // lokaal plaatje gebruiken
} else {
  imgSrc = `nui://ox_inventory/web/images/${r.name}.png`;
}

el.innerHTML = `
  <img src="${imgSrc}" onerror="this.onerror=null;this.src='nui://ox_inventory/web/images/unknown.png'">
  <span>${r.label || r.name}</span>`;

    wheel.appendChild(el);
  });

  const itemWidth = 140 + 8;
  const totalWidth = seq.length * itemWidth;
  wheel.style.width = `${totalWidth}px`;
  wheel.style.left = '0px';

  const stopIndex = finalPos;
  const centerOffset = (container.clientWidth / 2) - (itemWidth / 2);
  const finalLeft = -(stopIndex * itemWidth) + centerOffset;

  const duration = 9000;
  let startTime = null;
  function animate(timestamp) {
    if (!startTime) startTime = timestamp;
    const progress = Math.min((timestamp - startTime) / duration, 1);
    // cubic ease-out
    const eased = 1 - Math.pow(1 - progress, 3);
    const currentLeft = 0 + (finalLeft - 0) * eased;
    wheel.style.left = currentLeft + 'px';

    if (progress < 1) requestAnimationFrame(animate);
    else finishSpin();
  }
  requestAnimationFrame(animate);

  function finishSpin() {
    fetch(`https://${GetParentResourceName()}/finishSpin`, {
      method: 'POST',
      body: JSON.stringify({ reward: finalReward })
    });
    setTimeout(() => {
      document.body.style.display = 'none';
      isSpinning = false;
    }, 800);
  }
}
