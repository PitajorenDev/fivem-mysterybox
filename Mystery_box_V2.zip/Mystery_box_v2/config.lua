Config = {}

Config.Rarities = {
    common = { color = '#b0b0b0', sound = 'SELECT', soundset = 'HUD_FRONTEND_DEFAULT_SOUNDSET' },
    rare = { color = '#00bfff', sound = 'CHALLENGE_UNLOCKED', soundset = 'HUD_AWARDS' },
    epic = { color = '#a020f0', sound = 'WEAPON_PURCHASE', soundset = 'HUD_AMMO_SHOP_SOUNDSET' },
    legendary = { color = '#ffb700', sound = 'Mission_Pass_Notify', soundset = 'DLC_HEISTS_GENERAL_FRONTEND_SOUNDS' }
}

Config.Rewards = {
    { type = 'item', name = 'water', count = 3, chance = 35, rarity = 'common', label = 'Water' },
    { type = 'item', name = 'bandage', count = 2, chance = 25, rarity = 'rare', label = 'Bandage' },
    { type = 'item', name = 'armour', count = 1, chance = 20, rarity = 'epic', label = 'Body Armor' },
    { type = 'weapon', name = 'weapon_pistol', count = 1, chance = 100, rarity = 'legendary', label = 'Pistol' },
    { type = 'item', name = 'ammo-9', count = 24, chance = 1, rarity = 'legendary', label = '9mm' },
    { type = 'item', name = 'casino_chips', count = 20000, chance = 5, rarity = 'rare', label = 'casino chips' },
    { type = 'money', amount = 5000, chance = 5, rarity = 'epic', label = 'Cash Bonus' }
}
